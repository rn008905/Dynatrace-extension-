import os
import time
import json
import glob
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--paths', type=str, required=True)
args = parser.parse_args()

now = time.time()
metrics = []

path_list = args.paths.split(',')

for path in path_list:
    path = path.strip()
    if "*" in path:
        files = [f for f in glob.glob(path + "/**", recursive=True) if os.path.isfile(f)]
        metrics.append({
            "path": path,
            "file_count": len(files)
        })
        for file in files:
            stat = os.stat(file)
            created_time = stat.st_ctime
            age_minutes = (now - created_time) / 60
            metrics.append({
                "filename": file,
                "created": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(created_time)),
                "age_minutes": round(age_minutes, 2),
                "size": stat.st_size
            })
    else:
        exists = 1 if os.path.exists(path) else 0
        metrics.append({
            "path": path,
            "exists": exists
        })

print(json.dumps(metrics))
